var username = new URL(location.href).searchParams.get("username");
var user;

$(document).ready(function () {

    $(function () {
        $('[data-toggle="tooltip"]').tooltip();
    });

    getUsuario().then(function () {
        
        $("#mi-perfil-btn").attr("href","profile.html?username=" + username);
        
        //$("#user-saldo").html(user.saldo.toFixed(2) + "$"); //Esto servia para poner el saldo arriba a la derecha

        getProducto(false, "ASC");

        $("#ordenar-vatios").click(ordenarProductos);
    });
});


async function getUsuario() {

    await $.ajax({
        type: "GET",
        dataType: "html",
        url: "./ServletUsuarioPedir",
        data: $.param({
            username: username
        }),
        success: function (result) {
            let parsedResult = JSON.parse(result);

            if (parsedResult != false) {
                user = parsedResult;
            } else {
                console.log("Error recuperando los datos del usuario");
            }
        }
    });

}
function getProducto(ordenar, orden) {

    $.ajax({
        type: "GET",
        dataType: "html",
        url: "./ServletProductoListar",
        data: $.param({
            ordenar: ordenar,
            orden: orden
        }),
        success: function (result) {
            let parsedResult = JSON.parse(result);

            if (parsedResult != false) {
                mostrarPeliculas(parsedResult);
            } else {
                console.log("Error recuperando los datos de los productos");
            }
        }
    });
}
function mostrarProducto(producto) { //nombre de la tabla 

    let contenido = "";

    $.each(producto, function (index, productos) {

        prod = JSON.parse(producto);
        let precio;

        if (producto.cantidad > 0) {

            /* if (user.premium) { //Aqui se hace un descuento para 

                if (pelicula.novedad) {
                    precio = (2 - (2 * 0.1));
                } else {
                    precio = (1 - (1 * 0.1));
                }
            } else {
                if (pelicula.novedad) {
                    precio = 2;
                } else {
                    precio = 1;
                }
            } 
            */

            contenido += '<tr><th scope="row">' + producto.id_producto + '</th>' +
                    '<td>' + producto.tipo + '</td>' +
                    '<td>' + producto.vatios + '</td>' +
                    '<td>' + producto.voltaje + '</td>' +
                    '<td>' + producto.cantidad + '</td>';
                    //'<td>
            contenido += '></td>' +
                    '<td>' + precio + '</td>' +
                    '<td><button onclick="alquilarPelicula(' + producto.id + ',' + precio + ');" class="btn btn-success" ';
            if (user.saldo < precio) {
                contenido += ' disabled ';
            }

            contenido += '>Reservar</button></td></tr>'

        }//end<input type="checkbox" name="novedad" id="novedad' + producto.id + '" disabled ';
            /*if (pelicula.novedad) {
                contenido += 'checked';
            }*/
    });
    $("#productos-tbody").html(contenido);//    $("#peliculas-tbody").html(contenido);
}
//24/09/2022
function ordenarProductos() {

    if ($("#icono-ordenar").hasClass("fa-sort")) {
        getPeliculas(true, "ASC");
        $("#icono-ordenar").removeClass("fa-sort");
        $("#icono-ordenar").addClass("fa-sort-down");
    } else if ($("#icono-ordenar").hasClass("fa-sort-down")) {
        getPeliculas(true, "DESC");
        $("#icono-ordenar").removeClass("fa-sort-down");
        $("#icono-ordenar").addClass("fa-sort-up");
    } else if ($("#icono-ordenar").hasClass("fa-sort-up")) {
        getPeliculas(false, "ASC");
        $("#icono-ordenar").removeClass("fa-sort-up");
        $("#icono-ordenar").addClass("fa-sort");
    }
}
function cotizarProducto(id, precio) {

    $.ajax({
        type: "GET",
        dataType: "html",
        url: "./ServletProductoAlquilar",
        data: $.param({
            id: id,
            username: username

        }),
        success: function (result) {
            let parsedResult = JSON.parse(result);

            if (parsedResult != false) {
                restarDinero(precio).then(function () {
                    location.reload();
                })
            } else {
                console.log("Error en la compra del producto");
            }
        }
    });
}


/*async function restarDinero(precio) {

    await $.ajax({
        type: "GET",
        dataType: "html",
        url: "./ServletUsuarioRestarDinero",
        data: $.param({
            username: username,
            saldo: parseFloat(user.saldo - precio)

        }),
        success: function (result) {
            let parsedResult = JSON.parse(result);

            if (parsedResult != false) {
                console.log("Saldo actualizado");
            } else {
                console.log("Error en el proceso de pago");
            }
        }
    });
}*/