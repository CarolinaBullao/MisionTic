package controller;

public interface ICotizacionController {
	
	public String listarCotizacion(String username);

}