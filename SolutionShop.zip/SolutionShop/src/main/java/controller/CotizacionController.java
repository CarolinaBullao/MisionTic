package controller;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import java.util.List;

import com.google.gson.Gson;

import beans.Cotizacion;
import connection.DBConnection;

public class CotizacionController implements ICotizacionController {

    @Override
    public String listarCotizacion(String username) {

        Gson gson = new Gson();

        DBConnection con = new DBConnection();

        String sql = "SELECT l.id_producto, l.tipo, l.vatios, l.voltaje, l.cantidad, l.valor, a.fecha FROM producto l " //producto es igual a "l"
                + "INNER JOIN cotizacion a ON l.id_producto = a.id_cotizacion INNER JOIN usuario u ON a.username = u.username " //cotizacion = "a", usuario = "u"
                + "WHERE a.username = '" + username + "'";

        List<String> cotizaciones = new ArrayList<String>();

        try {

            Statement st = con.getConnection().createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                int id_cotizacion = rs.getInt("id_cotizacion");
                Date fecha = rs.getDate("fecha");
                int tiempo_solh = rs.getInt("tiempo_solh");
                Double precio_kwh = rs.getDouble("precio_kwh");
                Double promedio_consumo = rs.getDouble("promedio_consumo");
                //String username = rs.getString("username"); //si no funciona, corre
                int id_producto = rs.getInt("fecha");

                Cotizacion cotizacion = new Cotizacion(id_cotizacion, fecha,
                        tiempo_solh, precio_kwh, promedio_consumo, username, id_producto);

                return gson.toJson(cotizacion);
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
            con.desconectar();
        }
        return gson.toJson(cotizaciones);
    }
}
